"""
Jennifer Larsen
10/25/2023
This program uses packages and modules to display set greetings, authors, dictionaries and sets.
"""


def print_dict(input_dict):
    for key, value in input_dict.items():
        print(f"{key}: {value}")